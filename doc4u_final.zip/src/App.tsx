import React, { useState, useMemo } from 'react';
import { Search, MapPin, Phone, Navigation } from 'lucide-react';

// Data
const symptoms = [
  { symptom: "Dry or itchy skin", specialist: "Dermatologist" },
  { symptom: "Chest pain", specialist: "Cardiologist" },
  { symptom: "Frequent headaches", specialist: "Neurologist" },
  { symptom: "Stomach pain", specialist: "Gastroenterologist" },
  { symptom: "Joint stiffness", specialist: "Rheumatologist" },
  { symptom: "Irregular periods", specialist: "Gynecologist" },
  { symptom: "Pelvic pain", specialist: "Gynecologist" },
  { symptom: "Any other", specialist: "General Physician" }
];

const locations = ["Delhi", "Faridabad", "Noida", "Bulandshahr", "Ghaziabad", "Gurgaon"];

const doctors = [
  {
    "name": "Dr. Pooja Kumar",
    "specialization": "Dermatologist",
    "city": "Delhi",
    "contact": "+91 7738743962",
    "address": "72, Sector 22, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/503,285"
  },
  {
    "name": "Dr. Sonia Singh",
    "specialization": "Dermatologist",
    "city": "Delhi",
    "contact": "+91 7618767453",
    "address": "269, MG Road, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/578,567"
  },
  {
    "name": "Dr. Sonia Singh",
    "specialization": "Dermatologist",
    "city": "Delhi",
    "contact": "+91 8975134201",
    "address": "426, Main Street, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/560,952"
  },
  {
    "name": "Dr. Sonia Mehta",
    "specialization": "Dermatologist",
    "city": "Delhi",
    "contact": "+91 8048968780",
    "address": "401, Nehru Nagar, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/787,558"
  },
  {
    "name": "Dr. Amit Sharma",
    "specialization": "Dermatologist",
    "city": "Delhi",
    "contact": "+91 8503394436",
    "address": "13, Gandhi Road, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/416,628"
  },
  {
    "name": "Dr. Vikram Singh",
    "specialization": "Gynaecologist",
    "city": "Delhi",
    "contact": "+91 7157713800",
    "address": "204, Main Street, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/351,959"
  },
  {
    "name": "Dr. Rajesh Mehta",
    "specialization": "Gynaecologist",
    "city": "Delhi",
    "contact": "+91 9324933520",
    "address": "300, Gandhi Road, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/827,456"
  },
  {
    "name": "Dr. Rajesh Verma",
    "specialization": "Gynaecologist",
    "city": "Delhi",
    "contact": "+91 9107862860",
    "address": "212, Sector 22, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/177,563"
  },
  {
    "name": "Dr. Rajesh Sharma",
    "specialization": "Gynaecologist",
    "city": "Delhi",
    "contact": "+91 8309076528",
    "address": "281, MG Road, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/831,937"
  },
  {
    "name": "Dr. Ravi Sharma",
    "specialization": "Gynaecologist",
    "city": "Delhi",
    "contact": "+91 9061183958",
    "address": "211, MG Road, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/212,637"
  },
  {
    "name": "Dr. Ravi Verma",
    "specialization": "Cardiologist",
    "city": "Delhi",
    "contact": "+91 8260222216",
    "address": "352, Gandhi Road, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/183,848"
  },
  {
    "name": "Dr. Pooja Singh",
    "specialization": "Cardiologist",
    "city": "Delhi",
    "contact": "+91 8920902598",
    "address": "53, Nehru Nagar, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/945,356"
  },
  {
    "name": "Dr. Amit Mehta",
    "specialization": "Cardiologist",
    "city": "Delhi",
    "contact": "+91 8671645227",
    "address": "347, Gandhi Road, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/911,590"
  },
  {
    "name": "Dr. Neha Singh",
    "specialization": "Cardiologist",
    "city": "Delhi",
    "contact": "+91 8246019281",
    "address": "483, MG Road, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/650,267"
  },
  {
    "name": "Dr. Neha Singh",
    "specialization": "Cardiologist",
    "city": "Delhi",
    "contact": "+91 7317157560",
    "address": "295, Sector 22, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/848,422"
  },
  {
    "name": "Dr. Vikram Gupta",
    "specialization": "Neurologist",
    "city": "Delhi",
    "contact": "+91 7192880954",
    "address": "220, Gandhi Road, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/419,954"
  },
  {
    "name": "Dr. Pooja Mehta",
    "specialization": "Neurologist",
    "city": "Delhi",
    "contact": "+91 9639606396",
    "address": "146, Gandhi Road, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/558,430"
  },
  {
    "name": "Dr. Ravi Verma",
    "specialization": "Neurologist",
    "city": "Delhi",
    "contact": "+91 9530324127",
    "address": "220, Nehru Nagar, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/310,375"
  },
  {
    "name": "Dr. Priya Singh",
    "specialization": "Neurologist",
    "city": "Delhi",
    "contact": "+91 9853014091",
    "address": "188, MG Road, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/473,321"
  },
  {
    "name": "Dr. Amit Mehta",
    "specialization": "Neurologist",
    "city": "Delhi",
    "contact": "+91 9419990759",
    "address": "100, MG Road, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/834,783"
  },
  {
    "name": "Dr. Sonia Singh",
    "specialization": "Gastroenterologist",
    "city": "Delhi",
    "contact": "+91 9314799363",
    "address": "116, Nehru Nagar, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/917,440"
  },
  {
    "name": "Dr. Rajesh Gupta",
    "specialization": "Gastroenterologist",
    "city": "Delhi",
    "contact": "+91 9507648474",
    "address": "354, Main Street, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/842,147"
  },
  {
    "name": "Dr. Neha Verma",
    "specialization": "Gastroenterologist",
    "city": "Delhi",
    "contact": "+91 7332643851",
    "address": "116, MG Road, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/825,763"
  },
  {
    "name": "Dr. Vikram Sharma",
    "specialization": "Gastroenterologist",
    "city": "Delhi",
    "contact": "+91 8185193022",
    "address": "78, Gandhi Road, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/863,999"
  },
  {
    "name": "Dr. Rajesh Mehta",
    "specialization": "Gastroenterologist",
    "city": "Delhi",
    "contact": "+91 7376840812",
    "address": "247, Nehru Nagar, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/745,346"
  },
  {
    "name": "Dr. Vikram Kumar",
    "specialization": "Rheumatologist",
    "city": "Delhi",
    "contact": "+91 7993936208",
    "address": "180, Main Street, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/188,874"
  },
  {
    "name": "Dr. Rajesh Singh",
    "specialization": "Rheumatologist",
    "city": "Delhi",
    "contact": "+91 8661036206",
    "address": "77, Gandhi Road, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/708,284"
  },
  {
    "name": "Dr. Ravi Verma",
    "specialization": "Rheumatologist",
    "city": "Delhi",
    "contact": "+91 9007635253",
    "address": "282, Sector 22, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/745,472"
  },
  {
    "name": "Dr. Vikram Kumar",
    "specialization": "Rheumatologist",
    "city": "Delhi",
    "contact": "+91 8629015605",
    "address": "104, Nehru Nagar, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/731,886"
  },
  {
    "name": "Dr. Rajesh Sharma",
    "specialization": "Rheumatologist",
    "city": "Delhi",
    "contact": "+91 8082439028",
    "address": "44, Sector 22, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/719,159"
  },
  {
    "name": "Dr. Pooja Gupta",
    "specialization": "General Physician",
    "city": "Delhi",
    "contact": "+91 9931697545",
    "address": "253, Main Street, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/365,386"
  },
  {
    "name": "Dr. Rajesh Gupta",
    "specialization": "General Physician",
    "city": "Delhi",
    "contact": "+91 8231001318",
    "address": "31, Nehru Nagar, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/769,638"
  },
  {
    "name": "Dr. Priya Mehta",
    "specialization": "General Physician",
    "city": "Delhi",
    "contact": "+91 7489114186",
    "address": "74, Sector 22, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/293,520"
  },
  {
    "name": "Dr. Neha Mehta",
    "specialization": "General Physician",
    "city": "Delhi",
    "contact": "+91 7813092084",
    "address": "199, Gandhi Road, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/813,102"
  },
  {
    "name": "Dr. Pooja Verma",
    "specialization": "General Physician",
    "city": "Delhi",
    "contact": "+91 9393328110",
    "address": "244, Main Street, Delhi, India",
    "google_maps_link": "https://www.google.com/maps/place/554,147"
  },
  {
        "name": "Dr. Rajesh Kumar",
        "specialization": "Dermatologist",
        "city": "Faridabad",
        "contact": "+91 7891122230",
        "address": "266, MG Road, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=266%2C+MG+Road%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Ravi Verma",
        "specialization": "Dermatologist",
        "city": "Faridabad",
        "contact": "+91 8079289853",
        "address": "274, Sector 22, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=274%2C+Sector+22%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Sonia Gupta",
        "specialization": "Dermatologist",
        "city": "Faridabad",
        "contact": "+91 9803733541",
        "address": "1, Nehru Nagar, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=1%2C+Nehru+Nagar%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Priya Gupta",
        "specialization": "Dermatologist",
        "city": "Faridabad",
        "contact": "+91 9443729055",
        "address": "360, MG Road, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=360%2C+MG+Road%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Neha Sharma",
        "specialization": "Dermatologist",
        "city": "Faridabad",
        "contact": "+91 9108033089",
        "address": "343, Main Street, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=343%2C+Main+Street%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Neha Mehta",
        "specialization": "Gynaecologist",
        "city": "Faridabad",
        "contact": "+91 8630424766",
        "address": "165, MG Road, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=165%2C+MG+Road%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Amit Kumar",
        "specialization": "Gynaecologist",
        "city": "Faridabad",
        "contact": "+91 8433256893",
        "address": "203, Sector 22, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=203%2C+Sector+22%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Neha Gupta",
        "specialization": "Gynaecologist",
        "city": "Faridabad",
        "contact": "+91 9019316233",
        "address": "58, Main Street, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=58%2C+Main+Street%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Priya Mehta",
        "specialization": "Gynaecologist",
        "city": "Faridabad",
        "contact": "+91 9457132377",
        "address": "252, Nehru Nagar, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=252%2C+Nehru+Nagar%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Pooja Singh",
        "specialization": "Gynaecologist",
        "city": "Faridabad",
        "contact": "+91 9151082697",
        "address": "347, Main Street, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=347%2C+Main+Street%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Pooja Sharma",
        "specialization": "Cardiologist",
        "city": "Faridabad",
        "contact": "+91 9191714119",
        "address": "155, Gandhi Road, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=155%2C+Gandhi+Road%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Sonia Kumar",
        "specialization": "Cardiologist",
        "city": "Faridabad",
        "contact": "+91 8643516980",
        "address": "104, Nehru Nagar, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=104%2C+Nehru+Nagar%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Neha Kumar",
        "specialization": "Cardiologist",
        "city": "Faridabad",
        "contact": "+91 9755900824",
        "address": "258, Gandhi Road, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=258%2C+Gandhi+Road%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Neha Verma",
        "specialization": "Cardiologist",
        "city": "Faridabad",
        "contact": "+91 9919364770",
        "address": "174, Gandhi Road, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=174%2C+Gandhi+Road%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Ravi Gupta",
        "specialization": "Cardiologist",
        "city": "Faridabad",
        "contact": "+91 7657443700",
        "address": "389, Main Street, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=389%2C+Main+Street%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Pooja Mehta",
        "specialization": "Neurologist",
        "city": "Faridabad",
        "contact": "+91 7818279538",
        "address": "402, Gandhi Road, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=402%2C+Gandhi+Road%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Ravi Singh",
        "specialization": "Neurologist",
        "city": "Faridabad",
        "contact": "+91 7094083215",
        "address": "107, Main Street, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=107%2C+Main+Street%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Rajesh Singh",
        "specialization": "Neurologist",
        "city": "Faridabad",
        "contact": "+91 9001725552",
        "address": "4, Main Street, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=4%2C+Main+Street%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Pooja Kumar",
        "specialization": "Neurologist",
        "city": "Faridabad",
        "contact": "+91 7576814965",
        "address": "401, Sector 22, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=401%2C+Sector+22%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Vikram Verma",
        "specialization": "Neurologist",
        "city": "Faridabad",
        "contact": "+91 8507599888",
        "address": "342, Nehru Nagar, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=342%2C+Nehru+Nagar%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Pooja Kumar",
        "specialization": "Gastroenterologist",
        "city": "Faridabad",
        "contact": "+91 8998975725",
        "address": "418, MG Road, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=418%2C+MG+Road%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Neha Mehta",
        "specialization": "Gastroenterologist",
        "city": "Faridabad",
        "contact": "+91 9851465225",
        "address": "305, Gandhi Road, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=305%2C+Gandhi+Road%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Amit Kumar",
        "specialization": "Gastroenterologist",
        "city": "Faridabad",
        "contact": "+91 8010112801",
        "address": "3, Nehru Nagar, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=3%2C+Nehru+Nagar%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Rajesh Singh",
        "specialization": "Gastroenterologist",
        "city": "Faridabad",
        "contact": "+91 7946119133",
        "address": "394, Sector 22, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=394%2C+Sector+22%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Amit Verma",
        "specialization": "Gastroenterologist",
        "city": "Faridabad",
        "contact": "+91 7362121517",
        "address": "312, Nehru Nagar, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=312%2C+Nehru+Nagar%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Amit Kumar",
        "specialization": "Rheumatologist",
        "city": "Faridabad",
        "contact": "+91 8989205120",
        "address": "199, Nehru Nagar, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=199%2C+Nehru+Nagar%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Pooja Kumar",
        "specialization": "Rheumatologist",
        "city": "Faridabad",
        "contact": "+91 8029500932",
        "address": "248, Nehru Nagar, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=248%2C+Nehru+Nagar%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Priya Gupta",
        "specialization": "Rheumatologist",
        "city": "Faridabad",
        "contact": "+91 8251642288",
        "address": "98, Sector 22, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=98%2C+Sector+22%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Amit Kumar",
        "specialization": "Rheumatologist",
        "city": "Faridabad",
        "contact": "+91 7209900329",
        "address": "341, MG Road, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=341%2C+MG+Road%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Rajesh Kumar",
        "specialization": "Rheumatologist",
        "city": "Faridabad",
        "contact": "+91 8249599510",
        "address": "421, Sector 22, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=421%2C+Sector+22%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Neha Verma",
        "specialization": "General Physician",
        "city": "Faridabad",
        "contact": "+91 9433535064",
        "address": "240, MG Road, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=240%2C+MG+Road%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Pooja Singh",
        "specialization": "General Physician",
        "city": "Faridabad",
        "contact": "+91 9998294701",
        "address": "407, Sector 22, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=407%2C+Sector+22%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Priya Kumar",
        "specialization": "General Physician",
        "city": "Faridabad",
        "contact": "+91 8680345253",
        "address": "317, MG Road, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=317%2C+MG+Road%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Sonia Verma",
        "specialization": "General Physician",
        "city": "Faridabad",
        "contact": "+91 9211028517",
        "address": "49, Nehru Nagar, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=49%2C+Nehru+Nagar%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Amit Kumar",
        "specialization": "General Physician",
        "city": "Faridabad",
        "contact": "+91 9532770115",
        "address": "26, MG Road, Faridabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=26%2C+MG+Road%2C+Faridabad%2C+India"
    },
    {
        "name": "Dr. Ravi Gupta",
        "specialization": "Dermatologist",
        "city": "Noida",
        "contact": "+91 9519844047",
        "address": "173, Gandhi Road, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=173%2C+Gandhi+Road%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Neha Gupta",
        "specialization": "Dermatologist",
        "city": "Noida",
        "contact": "+91 9344389539",
        "address": "391, Gandhi Road, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=391%2C+Gandhi+Road%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Priya Sharma",
        "specialization": "Dermatologist",
        "city": "Noida",
        "contact": "+91 8728673310",
        "address": "8, Main Street, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=8%2C+Main+Street%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Ravi Verma",
        "specialization": "Dermatologist",
        "city": "Noida",
        "contact": "+91 7375863615",
        "address": "13, Nehru Nagar, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=13%2C+Nehru+Nagar%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Neha Kumar",
        "specialization": "Dermatologist",
        "city": "Noida",
        "contact": "+91 9744056412",
        "address": "20, Gandhi Road, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=20%2C+Gandhi+Road%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Vikram Gupta",
        "specialization": "Gynaecologist",
        "city": "Noida",
        "contact": "+91 9130751842",
        "address": "209, MG Road, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=209%2C+MG+Road%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Rajesh Mehta",
        "specialization": "Gynaecologist",
        "city": "Noida",
        "contact": "+91 9341904334",
        "address": "355, MG Road, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=355%2C+MG+Road%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Ravi Singh",
        "specialization": "Gynaecologist",
        "city": "Noida",
        "contact": "+91 8841495815",
        "address": "77, MG Road, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=77%2C+MG+Road%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Ravi Verma",
        "specialization": "Gynaecologist",
        "city": "Noida",
        "contact": "+91 9528146959",
        "address": "207, Gandhi Road, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=207%2C+Gandhi+Road%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Rajesh Gupta",
        "specialization": "Gynaecologist",
        "city": "Noida",
        "contact": "+91 7245938354",
        "address": "78, MG Road, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=78%2C+MG+Road%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Sonia Sharma",
        "specialization": "Cardiologist",
        "city": "Noida",
        "contact": "+91 7399546040",
        "address": "268, MG Road, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=268%2C+MG+Road%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Pooja Sharma",
        "specialization": "Cardiologist",
        "city": "Noida",
        "contact": "+91 7926598968",
        "address": "303, Nehru Nagar, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=303%2C+Nehru+Nagar%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Amit Sharma",
        "specialization": "Cardiologist",
        "city": "Noida",
        "contact": "+91 8219111596",
        "address": "316, Sector 22, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=316%2C+Sector+22%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Neha Singh",
        "specialization": "Cardiologist",
        "city": "Noida",
        "contact": "+91 8860120127",
        "address": "48, MG Road, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=48%2C+MG+Road%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Sonia Sharma",
        "specialization": "Cardiologist",
        "city": "Noida",
        "contact": "+91 8367853689",
        "address": "59, Main Street, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=59%2C+Main+Street%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Rajesh Sharma",
        "specialization": "Neurologist",
        "city": "Noida",
        "contact": "+91 8673344007",
        "address": "312, MG Road, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=312%2C+MG+Road%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Vikram Mehta",
        "specialization": "Neurologist",
        "city": "Noida",
        "contact": "+91 7214164624",
        "address": "194, MG Road, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=194%2C+MG+Road%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Rajesh Sharma",
        "specialization": "Neurologist",
        "city": "Noida",
        "contact": "+91 8611607208",
        "address": "99, Sector 22, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=99%2C+Sector+22%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Pooja Verma",
        "specialization": "Neurologist",
        "city": "Noida",
        "contact": "+91 8974097314",
        "address": "108, MG Road, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=108%2C+MG+Road%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Rajesh Verma",
        "specialization": "Neurologist",
        "city": "Noida",
        "contact": "+91 7473770885",
        "address": "217, Gandhi Road, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=217%2C+Gandhi+Road%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Vikram Sharma",
        "specialization": "Gastroenterologist",
        "city": "Noida",
        "contact": "+91 7340392944",
        "address": "200, Nehru Nagar, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=200%2C+Nehru+Nagar%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Sonia Sharma",
        "specialization": "Gastroenterologist",
        "city": "Noida",
        "contact": "+91 7481847069",
        "address": "443, Gandhi Road, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=443%2C+Gandhi+Road%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Neha Mehta",
        "specialization": "Gastroenterologist",
        "city": "Noida",
        "contact": "+91 8656775106",
        "address": "272, Main Street, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=272%2C+Main+Street%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Amit Singh",
        "specialization": "Gastroenterologist",
        "city": "Noida",
        "contact": "+91 7957181923",
        "address": "328, MG Road, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=328%2C+MG+Road%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Sonia Verma",
        "specialization": "Gastroenterologist",
        "city": "Noida",
        "contact": "+91 7253268984",
        "address": "260, Gandhi Road, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=260%2C+Gandhi+Road%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Amit Singh",
        "specialization": "Rheumatologist",
        "city": "Noida",
        "contact": "+91 7360325660",
        "address": "294, Nehru Nagar, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=294%2C+Nehru+Nagar%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Amit Sharma",
        "specialization": "Rheumatologist",
        "city": "Noida",
        "contact": "+91 9499351859",
        "address": "19, Gandhi Road, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=19%2C+Gandhi+Road%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Ravi Gupta",
        "specialization": "Rheumatologist",
        "city": "Noida",
        "contact": "+91 7783814990",
        "address": "444, Main Street, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=444%2C+Main+Street%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Neha Mehta",
        "specialization": "Rheumatologist",
        "city": "Noida",
        "contact": "+91 8162494597",
        "address": "125, Gandhi Road, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=125%2C+Gandhi+Road%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Vikram Gupta",
        "specialization": "Rheumatologist",
        "city": "Noida",
        "contact": "+91 7600049177",
        "address": "456, Nehru Nagar, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=456%2C+Nehru+Nagar%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Amit Kumar",
        "specialization": "General Physician",
        "city": "Noida",
        "contact": "+91 8579406647",
        "address": "357, Main Street, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=357%2C+Main+Street%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Ravi Verma",
        "specialization": "General Physician",
        "city": "Noida",
        "contact": "+91 8204125654",
        "address": "271, Main Street, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=271%2C+Main+Street%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Ravi Singh",
        "specialization": "General Physician",
        "city": "Noida",
        "contact": "+91 9042625524",
        "address": "283, Nehru Nagar, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=283%2C+Nehru+Nagar%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Rajesh Kumar",
        "specialization": "General Physician",
        "city": "Noida",
        "contact": "+91 9114860556",
        "address": "212, Gandhi Road, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=212%2C+Gandhi+Road%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Priya Gupta",
        "specialization": "General Physician",
        "city": "Noida",
        "contact": "+91 7572328077",
        "address": "21, Gandhi Road, Noida, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=21%2C+Gandhi+Road%2C+Noida%2C+India"
    },
    {
        "name": "Dr. Rajesh Verma",
        "specialization": "Dermatologist",
        "city": "Bulandshahr",
        "contact": "+91 7199352933",
        "address": "115, MG Road, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=115%2C+MG+Road%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Amit Kumar",
        "specialization": "Dermatologist",
        "city": "Bulandshahr",
        "contact": "+91 8468633755",
        "address": "134, Sector 22, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=134%2C+Sector+22%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Neha Gupta",
        "specialization": "Dermatologist",
        "city": "Bulandshahr",
        "contact": "+91 8049242228",
        "address": "470, Nehru Nagar, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=470%2C+Nehru+Nagar%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Priya Verma",
        "specialization": "Dermatologist",
        "city": "Bulandshahr",
        "contact": "+91 9416915741",
        "address": "387, Sector 22, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=387%2C+Sector+22%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Vikram Kumar",
        "specialization": "Dermatologist",
        "city": "Bulandshahr",
        "contact": "+91 8752760359",
        "address": "450, Gandhi Road, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=450%2C+Gandhi+Road%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Priya Verma",
        "specialization": "Gynaecologist",
        "city": "Bulandshahr",
        "contact": "+91 8562410589",
        "address": "80, Gandhi Road, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=80%2C+Gandhi+Road%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Sonia Kumar",
        "specialization": "Gynaecologist",
        "city": "Bulandshahr",
        "contact": "+91 9253326953",
        "address": "217, Nehru Nagar, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=217%2C+Nehru+Nagar%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Amit Kumar",
        "specialization": "Gynaecologist",
        "city": "Bulandshahr",
        "contact": "+91 9649892426",
        "address": "325, Gandhi Road, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=325%2C+Gandhi+Road%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Priya Singh",
        "specialization": "Gynaecologist",
        "city": "Bulandshahr",
        "contact": "+91 7023647598",
        "address": "99, MG Road, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=99%2C+MG+Road%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Pooja Gupta",
        "specialization": "Gynaecologist",
        "city": "Bulandshahr",
        "contact": "+91 9780462894",
        "address": "66, MG Road, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=66%2C+MG+Road%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Neha Sharma",
        "specialization": "Cardiologist",
        "city": "Bulandshahr",
        "contact": "+91 7313507819",
        "address": "24, Gandhi Road, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=24%2C+Gandhi+Road%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Ravi Kumar",
        "specialization": "Cardiologist",
        "city": "Bulandshahr",
        "contact": "+91 9417282391",
        "address": "65, Sector 22, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=65%2C+Sector+22%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Pooja Sharma",
        "specialization": "Cardiologist",
        "city": "Bulandshahr",
        "contact": "+91 7280074025",
        "address": "104, Nehru Nagar, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=104%2C+Nehru+Nagar%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Sonia Singh",
        "specialization": "Cardiologist",
        "city": "Bulandshahr",
        "contact": "+91 7087467183",
        "address": "393, MG Road, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=393%2C+MG+Road%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Vikram Sharma",
        "specialization": "Cardiologist",
        "city": "Bulandshahr",
        "contact": "+91 9751512815",
        "address": "211, MG Road, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=211%2C+MG+Road%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Neha Gupta",
        "specialization": "Neurologist",
        "city": "Bulandshahr",
        "contact": "+91 7656631466",
        "address": "360, MG Road, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=360%2C+MG+Road%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Rajesh Sharma",
        "specialization": "Neurologist",
        "city": "Bulandshahr",
        "contact": "+91 9662449627",
        "address": "308, Sector 22, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=308%2C+Sector+22%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Ravi Sharma",
        "specialization": "Neurologist",
        "city": "Bulandshahr",
        "contact": "+91 9887170816",
        "address": "142, Nehru Nagar, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=142%2C+Nehru+Nagar%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Priya Kumar",
        "specialization": "Neurologist",
        "city": "Bulandshahr",
        "contact": "+91 8249569094",
        "address": "480, Nehru Nagar, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=480%2C+Nehru+Nagar%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Priya Verma",
        "specialization": "Neurologist",
        "city": "Bulandshahr",
        "contact": "+91 7223048755",
        "address": "58, MG Road, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=58%2C+MG+Road%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Pooja Verma",
        "specialization": "Gastroenterologist",
        "city": "Bulandshahr",
        "contact": "+91 8067963270",
        "address": "398, Sector 22, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=398%2C+Sector+22%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Neha Singh",
        "specialization": "Gastroenterologist",
        "city": "Bulandshahr",
        "contact": "+91 7479542412",
        "address": "407, Main Street, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=407%2C+Main+Street%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Priya Verma",
        "specialization": "Gastroenterologist",
        "city": "Bulandshahr",
        "contact": "+91 9659827163",
        "address": "224, MG Road, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=224%2C+MG+Road%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Amit Verma",
        "specialization": "Gastroenterologist",
        "city": "Bulandshahr",
        "contact": "+91 7464419208",
        "address": "216, Gandhi Road, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=216%2C+Gandhi+Road%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Neha Mehta",
        "specialization": "Gastroenterologist",
        "city": "Bulandshahr",
        "contact": "+91 9300988904",
        "address": "438, MG Road, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=438%2C+MG+Road%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Pooja Kumar",
        "specialization": "Rheumatologist",
        "city": "Bulandshahr",
        "contact": "+91 8951568156",
        "address": "427, Main Street, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=427%2C+Main+Street%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Ravi Mehta",
        "specialization": "Rheumatologist",
        "city": "Bulandshahr",
        "contact": "+91 7716949052",
        "address": "183, MG Road, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=183%2C+MG+Road%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Pooja Verma",
        "specialization": "Rheumatologist",
        "city": "Bulandshahr",
        "contact": "+91 9559539472",
        "address": "331, Main Street, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=331%2C+Main+Street%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Pooja Verma",
        "specialization": "Rheumatologist",
        "city": "Bulandshahr",
        "contact": "+91 7457839238",
        "address": "207, Main Street, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=207%2C+Main+Street%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Rajesh Gupta",
        "specialization": "Rheumatologist",
        "city": "Bulandshahr",
        "contact": "+91 7765925297",
        "address": "499, Sector 22, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=499%2C+Sector+22%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Sonia Sharma",
        "specialization": "General Physician",
        "city": "Bulandshahr",
        "contact": "+91 8657983819",
        "address": "152, MG Road, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=152%2C+MG+Road%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Ravi Gupta",
        "specialization": "General Physician",
        "city": "Bulandshahr",
        "contact": "+91 9909223006",
        "address": "17, Gandhi Road, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=17%2C+Gandhi+Road%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Amit Gupta",
        "specialization": "General Physician",
        "city": "Bulandshahr",
        "contact": "+91 8929090427",
        "address": "136, Nehru Nagar, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=136%2C+Nehru+Nagar%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Vikram Gupta",
        "specialization": "General Physician",
        "city": "Bulandshahr",
        "contact": "+91 8414231488",
        "address": "289, Main Street, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=289%2C+Main+Street%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Neha Mehta",
        "specialization": "General Physician",
        "city": "Bulandshahr",
        "contact": "+91 9259206711",
        "address": "160, Sector 22, Bulandshahr, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=160%2C+Sector+22%2C+Bulandshahr%2C+India"
    },
    {
        "name": "Dr. Vikram Singh",
        "specialization": "Dermatologist",
        "city": "Ghaziabad",
        "contact": "+91 8853357081",
        "address": "76, Gandhi Road, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=76%2C+Gandhi+Road%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Sonia Gupta",
        "specialization": "Dermatologist",
        "city": "Ghaziabad",
        "contact": "+91 9415201777",
        "address": "447, Sector 22, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=447%2C+Sector+22%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Rajesh Gupta",
        "specialization": "Dermatologist",
        "city": "Ghaziabad",
        "contact": "+91 9006069574",
        "address": "286, Main Street, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=286%2C+Main+Street%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Ravi Sharma",
        "specialization": "Dermatologist",
        "city": "Ghaziabad",
        "contact": "+91 8402346895",
        "address": "176, Gandhi Road, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=176%2C+Gandhi+Road%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Priya Singh",
        "specialization": "Dermatologist",
        "city": "Ghaziabad",
        "contact": "+91 9572569003",
        "address": "277, MG Road, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=277%2C+MG+Road%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Priya Sharma",
        "specialization": "Gynaecologist",
        "city": "Ghaziabad",
        "contact": "+91 8488787134",
        "address": "499, Gandhi Road, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=499%2C+Gandhi+Road%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Vikram Mehta",
        "specialization": "Gynaecologist",
        "city": "Ghaziabad",
        "contact": "+91 7627728597",
        "address": "247, Gandhi Road, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=247%2C+Gandhi+Road%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Sonia Mehta",
        "specialization": "Gynaecologist",
        "city": "Ghaziabad",
        "contact": "+91 9810672026",
        "address": "314, Nehru Nagar, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=314%2C+Nehru+Nagar%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Neha Sharma",
        "specialization": "Gynaecologist",
        "city": "Ghaziabad",
        "contact": "+91 9164190388",
        "address": "396, Nehru Nagar, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=396%2C+Nehru+Nagar%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Pooja Kumar",
        "specialization": "Gynaecologist",
        "city": "Ghaziabad",
        "contact": "+91 8247254582",
        "address": "70, Gandhi Road, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=70%2C+Gandhi+Road%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Amit Sharma",
        "specialization": "Cardiologist",
        "city": "Ghaziabad",
        "contact": "+91 9436108939",
        "address": "88, Nehru Nagar, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=88%2C+Nehru+Nagar%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Rajesh Mehta",
        "specialization": "Cardiologist",
        "city": "Ghaziabad",
        "contact": "+91 9674476453",
        "address": "2, Main Street, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=2%2C+Main+Street%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Ravi Gupta",
        "specialization": "Cardiologist",
        "city": "Ghaziabad",
        "contact": "+91 8032416952",
        "address": "469, MG Road, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=469%2C+MG+Road%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Rajesh Gupta",
        "specialization": "Cardiologist",
        "city": "Ghaziabad",
        "contact": "+91 8749428774",
        "address": "67, Nehru Nagar, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=67%2C+Nehru+Nagar%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Neha Sharma",
        "specialization": "Cardiologist",
        "city": "Ghaziabad",
        "contact": "+91 8473998068",
        "address": "137, Sector 22, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=137%2C+Sector+22%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Rajesh Gupta",
        "specialization": "Neurologist",
        "city": "Ghaziabad",
        "contact": "+91 7805724969",
        "address": "39, Main Street, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=39%2C+Main+Street%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Ravi Verma",
        "specialization": "Neurologist",
        "city": "Ghaziabad",
        "contact": "+91 9773968623",
        "address": "117, Sector 22, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=117%2C+Sector+22%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Sonia Singh",
        "specialization": "Neurologist",
        "city": "Ghaziabad",
        "contact": "+91 7164723581",
        "address": "33, Main Street, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=33%2C+Main+Street%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Pooja Verma",
        "specialization": "Neurologist",
        "city": "Ghaziabad",
        "contact": "+91 7696964704",
        "address": "198, Main Street, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=198%2C+Main+Street%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Ravi Singh",
        "specialization": "Neurologist",
        "city": "Ghaziabad",
        "contact": "+91 9536641835",
        "address": "279, Gandhi Road, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=279%2C+Gandhi+Road%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Amit Verma",
        "specialization": "Gastroenterologist",
        "city": "Ghaziabad",
        "contact": "+91 7329910131",
        "address": "300, Main Street, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=300%2C+Main+Street%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Priya Sharma",
        "specialization": "Gastroenterologist",
        "city": "Ghaziabad",
        "contact": "+91 9416609133",
        "address": "235, Main Street, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=235%2C+Main+Street%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Priya Singh",
        "specialization": "Gastroenterologist",
        "city": "Ghaziabad",
        "contact": "+91 8075313048",
        "address": "101, Nehru Nagar, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=101%2C+Nehru+Nagar%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Rajesh Singh",
        "specialization": "Gastroenterologist",
        "city": "Ghaziabad",
        "contact": "+91 8348542934",
        "address": "123, Sector 22, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=123%2C+Sector+22%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Amit Kumar",
        "specialization": "Gastroenterologist",
        "city": "Ghaziabad",
        "contact": "+91 9691595491",
        "address": "411, Sector 22, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=411%2C+Sector+22%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Sonia Gupta",
        "specialization": "Rheumatologist",
        "city": "Ghaziabad",
        "contact": "+91 8477377046",
        "address": "22, Nehru Nagar, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=22%2C+Nehru+Nagar%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Neha Gupta",
        "specialization": "Rheumatologist",
        "city": "Ghaziabad",
        "contact": "+91 9520089478",
        "address": "382, Gandhi Road, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=382%2C+Gandhi+Road%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Rajesh Singh",
        "specialization": "Rheumatologist",
        "city": "Ghaziabad",
        "contact": "+91 9611163761",
        "address": "60, Nehru Nagar, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=60%2C+Nehru+Nagar%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Pooja Kumar",
        "specialization": "Rheumatologist",
        "city": "Ghaziabad",
        "contact": "+91 7894840412",
        "address": "499, MG Road, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=499%2C+MG+Road%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Vikram Gupta",
        "specialization": "Rheumatologist",
        "city": "Ghaziabad",
        "contact": "+91 9261123752",
        "address": "259, Nehru Nagar, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=259%2C+Nehru+Nagar%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Ravi Sharma",
        "specialization": "General Physician",
        "city": "Ghaziabad",
        "contact": "+91 9051787239",
        "address": "356, Nehru Nagar, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=356%2C+Nehru+Nagar%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Rajesh Gupta",
        "specialization": "General Physician",
        "city": "Ghaziabad",
        "contact": "+91 8162005640",
        "address": "425, Sector 22, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=425%2C+Sector+22%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Vikram Verma",
        "specialization": "General Physician",
        "city": "Ghaziabad",
        "contact": "+91 8820132632",
        "address": "359, Main Street, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=359%2C+Main+Street%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Priya Mehta",
        "specialization": "General Physician",
        "city": "Ghaziabad",
        "contact": "+91 9038948152",
        "address": "213, Nehru Nagar, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=213%2C+Nehru+Nagar%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Amit Verma",
        "specialization": "General Physician",
        "city": "Ghaziabad",
        "contact": "+91 7423942293",
        "address": "85, Nehru Nagar, Ghaziabad, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=85%2C+Nehru+Nagar%2C+Ghaziabad%2C+India"
    },
    {
        "name": "Dr. Neha Sharma",
        "specialization": "Dermatologist",
        "city": "Gurgaon",
        "contact": "+91 7585848465",
        "address": "29, Gandhi Road, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=29%2C+Gandhi+Road%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Vikram Kumar",
        "specialization": "Dermatologist",
        "city": "Gurgaon",
        "contact": "+91 8725701058",
        "address": "431, Main Street, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=431%2C+Main+Street%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Priya Mehta",
        "specialization": "Dermatologist",
        "city": "Gurgaon",
        "contact": "+91 7391651746",
        "address": "70, Gandhi Road, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=70%2C+Gandhi+Road%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Priya Sharma",
        "specialization": "Dermatologist",
        "city": "Gurgaon",
        "contact": "+91 9924573979",
        "address": "369, Main Street, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=369%2C+Main+Street%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Rajesh Verma",
        "specialization": "Dermatologist",
        "city": "Gurgaon",
        "contact": "+91 8219385484",
        "address": "229, Nehru Nagar, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=229%2C+Nehru+Nagar%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Ravi Sharma",
        "specialization": "Gynaecologist",
        "city": "Gurgaon",
        "contact": "+91 8672999210",
        "address": "160, Nehru Nagar, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=160%2C+Nehru+Nagar%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Pooja Kumar",
        "specialization": "Gynaecologist",
        "city": "Gurgaon",
        "contact": "+91 7276435014",
        "address": "205, Main Street, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=205%2C+Main+Street%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Amit Singh",
        "specialization": "Gynaecologist",
        "city": "Gurgaon",
        "contact": "+91 9958105745",
        "address": "311, MG Road, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=311%2C+MG+Road%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Amit Kumar",
        "specialization": "Gynaecologist",
        "city": "Gurgaon",
        "contact": "+91 7350049679",
        "address": "379, Sector 22, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=379%2C+Sector+22%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Priya Gupta",
        "specialization": "Gynaecologist",
        "city": "Gurgaon",
        "contact": "+91 8436723107",
        "address": "105, Main Street, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=105%2C+Main+Street%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Neha Singh",
        "specialization": "Cardiologist",
        "city": "Gurgaon",
        "contact": "+91 7087359245",
        "address": "139, MG Road, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=139%2C+MG+Road%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Amit Mehta",
        "specialization": "Cardiologist",
        "city": "Gurgaon",
        "contact": "+91 8197290436",
        "address": "140, Nehru Nagar, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=140%2C+Nehru+Nagar%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Sonia Mehta",
        "specialization": "Cardiologist",
        "city": "Gurgaon",
        "contact": "+91 7194748867",
        "address": "151, Sector 22, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=151%2C+Sector+22%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Pooja Mehta",
        "specialization": "Cardiologist",
        "city": "Gurgaon",
        "contact": "+91 9766941384",
        "address": "493, Main Street, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=493%2C+Main+Street%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Vikram Gupta",
        "specialization": "Cardiologist",
        "city": "Gurgaon",
        "contact": "+91 9463993241",
        "address": "442, Gandhi Road, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=442%2C+Gandhi+Road%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Sonia Kumar",
        "specialization": "Neurologist",
        "city": "Gurgaon",
        "contact": "+91 7030575246",
        "address": "379, Nehru Nagar, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=379%2C+Nehru+Nagar%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Pooja Sharma",
        "specialization": "Neurologist",
        "city": "Gurgaon",
        "contact": "+91 9199777119",
        "address": "173, Gandhi Road, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=173%2C+Gandhi+Road%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Amit Gupta",
        "specialization": "Neurologist",
        "city": "Gurgaon",
        "contact": "+91 8033060359",
        "address": "325, Gandhi Road, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=325%2C+Gandhi+Road%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Sonia Verma",
        "specialization": "Neurologist",
        "city": "Gurgaon",
        "contact": "+91 8198580425",
        "address": "408, Nehru Nagar, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=408%2C+Nehru+Nagar%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Vikram Gupta",
        "specialization": "Neurologist",
        "city": "Gurgaon",
        "contact": "+91 8893522606",
        "address": "283, Gandhi Road, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=283%2C+Gandhi+Road%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Priya Gupta",
        "specialization": "Gastroenterologist",
        "city": "Gurgaon",
        "contact": "+91 7733115728",
        "address": "341, MG Road, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=341%2C+MG+Road%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Ravi Gupta",
        "specialization": "Gastroenterologist",
        "city": "Gurgaon",
        "contact": "+91 9871601045",
        "address": "307, Gandhi Road, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=307%2C+Gandhi+Road%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Priya Gupta",
        "specialization": "Gastroenterologist",
        "city": "Gurgaon",
        "contact": "+91 8149475153",
        "address": "144, Nehru Nagar, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=144%2C+Nehru+Nagar%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Amit Singh",
        "specialization": "Gastroenterologist",
        "city": "Gurgaon",
        "contact": "+91 7812540321",
        "address": "289, Nehru Nagar, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=289%2C+Nehru+Nagar%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Amit Kumar",
        "specialization": "Gastroenterologist",
        "city": "Gurgaon",
        "contact": "+91 7233137231",
        "address": "420, Main Street, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=420%2C+Main+Street%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Ravi Sharma",
        "specialization": "Rheumatologist",
        "city": "Gurgaon",
        "contact": "+91 7449407974",
        "address": "276, Nehru Nagar, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=276%2C+Nehru+Nagar%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Vikram Sharma",
        "specialization": "Rheumatologist",
        "city": "Gurgaon",
        "contact": "+91 9606000025",
        "address": "477, Nehru Nagar, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=477%2C+Nehru+Nagar%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Vikram Kumar",
        "specialization": "Rheumatologist",
        "city": "Gurgaon",
        "contact": "+91 7234221201",
        "address": "489, MG Road, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=489%2C+MG+Road%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Ravi Mehta",
        "specialization": "Rheumatologist",
        "city": "Gurgaon",
        "contact": "+91 8385420426",
        "address": "199, Nehru Nagar, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=199%2C+Nehru+Nagar%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Vikram Singh",
        "specialization": "Rheumatologist",
        "city": "Gurgaon",
        "contact": "+91 7494133643",
        "address": "400, Nehru Nagar, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=400%2C+Nehru+Nagar%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Ravi Sharma",
        "specialization": "General Physician",
        "city": "Gurgaon",
        "contact": "+91 7393649786",
        "address": "405, Sector 22, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=405%2C+Sector+22%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Pooja Gupta",
        "specialization": "General Physician",
        "city": "Gurgaon",
        "contact": "+91 9615667852",
        "address": "82, MG Road, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=82%2C+MG+Road%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Rajesh Sharma",
        "specialization": "General Physician",
        "city": "Gurgaon",
        "contact": "+91 9147192010",
        "address": "454, Sector 22, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=454%2C+Sector+22%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Sonia Singh",
        "specialization": "General Physician",
        "city": "Gurgaon",
        "contact": "+91 8312894532",
        "address": "214, Sector 22, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=214%2C+Sector+22%2C+Gurgaon%2C+India"
    },
    {
        "name": "Dr. Vikram Sharma",
        "specialization": "General Physician",
        "city": "Gurgaon",
        "contact": "+91 7525521205",
        "address": "427, Nehru Nagar, Gurgaon, India",
        "google_maps_link": "https://www.google.com/maps/search/?api=1&query=427%2C+Nehru+Nagar%2C+Gurgaon%2C+India"
    },
  // ... Add all the remaining doctors data here for other cities
];

function App() {
  const [selectedLocation, setSelectedLocation] = useState('');
  const [selectedSymptom, setSelectedSymptom] = useState('');
  const [showResults, setShowResults] = useState(false);

  const matchedDoctors = useMemo(() => {
    if (!selectedLocation || !selectedSymptom) return [];
    
    const specialist = symptoms.find(s => s.symptom === selectedSymptom)?.specialist;
    return doctors.filter(doctor => {
      const matchesLocation = doctor.city === selectedLocation;
      const matchesSpecialist = doctor.specialization === specialist || 
        // Handle the case for Gynecologist/Gynaecologist spelling variation
        (specialist === "Gynecologist" && doctor.specialization === "Gynaecologist");
      
      return matchesLocation && matchesSpecialist;
    });
  }, [selectedLocation, selectedSymptom]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setShowResults(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-indigo-900 mb-4">Doctor For You</h1>
          <p className="text-gray-600">Find the right specialist based on your symptoms</p>
        </div>

        <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-lg p-6 mb-8">
          <form onSubmit={handleSearch} className="space-y-6">
            <div>
              <label className="block text-gray-700 text-sm font-semibold mb-2">
                <MapPin className="inline-block w-5 h-5 mr-2 text-indigo-600" />
                Select Your Location
              </label>
              <select
                value={selectedLocation}
                onChange={(e) => setSelectedLocation(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                required
              >
                <option value="">Choose a location</option>
                {locations.map(location => (
                  <option key={location} value={location}>{location}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-gray-700 text-sm font-semibold mb-2">
                <Search className="inline-block w-5 h-5 mr-2 text-indigo-600" />
                What's troubling you?
              </label>
              <select
                value={selectedSymptom}
                onChange={(e) => setSelectedSymptom(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                required
              >
                <option value="">Select your symptom</option>
                {symptoms.map(({ symptom }) => (
                  <option key={symptom} value={symptom}>{symptom}</option>
                ))}
              </select>
            </div>

            <button
              type="submit"
              className="w-full bg-indigo-600 text-white py-3 px-6 rounded-lg hover:bg-indigo-700 transition-colors duration-200"
            >
              Find Doctors
            </button>
          </form>
        </div>

        {showResults && (
          <div className="max-w-4xl mx-auto">
            <h2 className="text-2xl font-semibold text-gray-800 mb-6">
              {matchedDoctors.length > 0 
                ? `Found ${matchedDoctors.length} doctors in ${selectedLocation}`
                : 'No doctors found for your criteria'}
            </h2>
            
            <div className="grid gap-6 md:grid-cols-2">
              {matchedDoctors.map((doctor, index) => (
                <div key={index} className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow duration-200">
                  <h3 className="text-xl font-semibold text-indigo-900 mb-2">{doctor.name}</h3>
                  <p className="text-gray-600 mb-4">{doctor.specialization}</p>
                  
                  <div className="space-y-2 text-sm text-gray-600">
                    <p className="flex items-center">
                      <MapPin className="w-4 h-4 mr-2 text-indigo-600" />
                      {doctor.address}
                    </p>
                    <p className="flex items-center">
                      <Phone className="w-4 h-4 mr-2 text-indigo-600" />
                      {doctor.contact}
                    </p>
                  </div>
                  
                  <a
                    href={doctor.google_maps_link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-4 inline-flex items-center text-indigo-600 hover:text-indigo-800"
                  >
                    <Navigation className="w-4 h-4 mr-1" />
                    Get Directions
                  </a>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;