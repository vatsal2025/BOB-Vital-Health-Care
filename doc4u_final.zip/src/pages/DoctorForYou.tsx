import { useState } from "react";

const doctors = [
    { name: "Dr. Rajesh Verma", specialization: "Dermatologist", city: "Delhi", contact: "+91 7490776199", address: "157, Nehru Nagar, Delhi, India", google_maps_link: "https://www.google.com/maps/search/?api=1&query=157%2C+Nehru+Nagar%2C+Delhi%2C+India" },
    { name: "Dr. Priya Gupta", specialization: "Dermatologist", city: "Delhi", contact: "+91 8717016798", address: "38, Main Street, Delhi, India", google_maps_link: "https://www.google.com/maps/search/?api=1&query=38%2C+Main+Street%2C+Delhi%2C+India" },
    { name: "Dr. Neha Sharma", specialization: "Gynaecologist", city: "Delhi", contact: "+91 8229848377", address: "464, Gandhi Road, Delhi, India", google_maps_link: "https://www.google.com/maps/search/?api=1&query=464%2C+Gandhi+Road%2C+Delhi%2C+India" }
];

export default function DoctorForYou() {
    const [location, setLocation] = useState("Delhi");
    const [specialist, setSpecialist] = useState("Dermatologist");
    const [filteredDoctors, setFilteredDoctors] = useState([]);

    const findDoctors = () => {
        const results = doctors.filter(doc => doc.city === location && doc.specialization === specialist);
        setFilteredDoctors(results);
    };

    return (
        <div className="text-center p-4">
            <h1 className="text-2xl font-bold">Find a Doctor for You</h1>
            <div className="mt-4">
                <label className="block">Select Your Location:</label>
                <select className="p-2 border" value={location} onChange={e => setLocation(e.target.value)}>
                    <option value="Delhi">Delhi</option>
                    <option value="Faridabad">Faridabad</option>
                    <option value="Noida">Noida</option>
                    <option value="Ghaziabad">Ghaziabad</option>
                </select>
            </div>
            <div className="mt-4">
                <label className="block">Select Your Symptom:</label>
                <select className="p-2 border" value={specialist} onChange={e => setSpecialist(e.target.value)}>
                    <option value="Dermatologist">Dry or itchy skin</option>
                    <option value="Cardiologist">Chest pain</option>
                    <option value="Neurologist">Frequent headaches</option>
                    <option value="Gastroenterologist">Stomach pain</option>
                    <option value="Rheumatologist">Joint stiffness</option>
                    <option value="Gynaecologist">Irregular periods</option>
                    <option value="Gynaecologist">Pelvic pain</option>
                    <option value="General Physician">Any other</option>
                </select>
            </div>
            <button className="mt-4 p-2 bg-blue-500 text-white" onClick={findDoctors}>Find Doctors</button>
            <div className="mt-4">
                <h2 className="text-xl font-bold">Available Doctors:</h2>
                {filteredDoctors.length > 0 ? (
                    filteredDoctors.map((doc, index) => (
                        <p key={index}>
                            <strong>{doc.name}</strong><br />📍 {doc.address}<br />📞 {doc.contact}<br />
                            <a href={doc.google_maps_link} target="_blank" className="text-blue-600">View on Map</a>
                        </p>
                    ))
                ) : (
                    <p>No doctors found for the selected criteria.</p>
                )}
            </div>
        </div>
    );
}
